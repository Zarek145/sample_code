/*
Name: William T. Brown
Course: CS3530 Intro to Networks
Assignment: Programming Assignment #1 - Web Server - one request
Due Date: Tuesday February 25, 2016
*/
/*
Resources used:
ftp://ftp.gnu.org/old-gnu/Manuals/glibc-2.2.3/html_chapter/libc_16.html
ftp://ftp.gnu.org/old-gnu/Manuals/glibc-2.2.3/html_chapter/libc_16.html#SEC305
http://man7.org/linux/man-pages/man3/getaddrinfo.3.html
*/

#include <stdio.h>
#include <stdlib.h>

#include <pthread.h>

#include <netdb.h>
#include <netinet/in.h>

#include <string.h>

#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BACKLOG 5

int threadCount = BACKLOG, connectfd, newsockfd;
char filter1[4];
char filter2[5];
char filter3[6];
char filter4[8];
char filter[17][8];
char address[30], blocked[4][30];
FILE *fileptr;
int filefd, block = 0, sockfd, numfiles, s;
struct addrinfo hints;
struct addrinfo *result, *rp;
char c;
char files[30][30];
char specification[30], filetoopen[32], file[30];

void *client_handler(void *arg);

int main( int argc, char *argv[]){
	int portno, clilen, i = 0, j = 0, k = 0, filefound = 0;
	char buffer[5120000];
	struct sockaddr_in serv_addr, cli_addr;
	socklen_t len;
	int n;
	pid_t pid, childPID, parentPID;
	int sock_listen;
	int sock_aClient;
	int *sock_tmp;
	pthread_t a_thread;
	void *thread_result;
	
	//create socket
	sock_listen = socket(AF_INET, SOCK_STREAM, 0);
	if(sock_listen < 0){
		printf("Fail on socket() call.\n");
		exit(0);
	}
	
	strcpy(filter[0], "ass");
	strcpy(filter[1], "shit");
	strcpy(filter[2], "fuck");
	strcpy(filter[3], "piss");
	strcpy(filter[4], "cock");
	strcpy(filter[6], "dick");
	strcpy(filter[7], "bitch");
	strcpy(filter[8], "Ass");
	strcpy(filter[9], "Shit");
	strcpy(filter[10], "Fuck");
	strcpy(filter[11], "Piss");
	strcpy(filter[12], "Cock");
	strcpy(filter[13], "Dick");
	strcpy(filter[14], "Bitch");
	strcpy(filter[15], "Bastard");
	strcpy(filter[16], "bastard");
	
	
	for(i = 0; i < 30; i++){
		specification[i] = '\0';
	}
	
	//Set up the "hints" struct for use later in getaddrinfo()
	memset(&hints, 0, sizeof(struct addrinfo));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_flags = 0;
	hints.ai_protocol = 0;
	
	//Blacklisted sites
	strcpy(blocked[0], "facebook");
	strcpy(blocked[1], "youtube");
	strcpy(blocked[2], "hulu");
	strcpy(blocked[3], "virus");
	
	//Opening a file to write the current files on the "server" to, so they can be pulled out from said file and into a string array.
	fileptr = fopen("./files.txt", "w+");
	
	if(fileptr == NULL){
		printf("Fail creating files.txt\n");
		exit(1);
	}
	filefd = fileno(fileptr);
	
	//forking to get files on server.
	pid = fork();
	if(pid < 0){
		printf("Fail on fork.\n");
		exit(1);
	}
	
	if(pid != 0){//parent
		wait(NULL);
	}
	if(pid == 0){//child
		dup2(filefd, 1);//close stdout and redirect it to the open file
		execl("/bin/ls", "/bin/ls", (char*)0);
	}
	
	bzero(buffer, 5120000);
	
	//Gather files from files.txt
	lseek(filefd, 0, SEEK_SET);//reset the read/write of the file to the beginning
	n = read(filefd, buffer, 5119999);
	if(n<0){
		printf("Error reading from file.\n");
		exit(1);
	}	
		
	if(fclose(fileptr) != 0){
		printf("Error closing file.\n");
		exit(1);
	}
	
	//Copy files from the buffer to the files array
	i = 0;
	while(i < n){
		if(buffer[i] == '\n'){
			files[j][k] = '\0';
			j++;
			k = 0;
			i++;
		}
		files[j][k++] = buffer[i];
		i++;
	}
	numfiles = j;
	
	
	//Initialize socket structure
	portno = 65324;
	
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port= htons(portno);
	
	//Bind socket to port
	if(bind(sock_listen, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0){
		printf("Error binding socket.\n");
		close(sock_listen);
		exit(1);
	}
	
	//Listen for connection
	if(listen(sock_listen, 5) < 0){
		printf("Fail on listen() call.\n");
		close(sock_listen);
		exit(1);
		
	}
	clilen = sizeof(cli_addr);
	
	printf("Waiting for client on portno %d\n", portno);

	while(1){
		if(threadCount < 1){
			sleep(1);
		}
		
		
		//Accept connection request from client
		sock_aClient = accept(sock_listen, (struct sockaddr *)&cli_addr, &clilen);
		
		if(sock_aClient == -1){
			printf("Error accepting socket.\n");
			close(sock_listen);
			exit(1);
		}
		
		printf("Got a connection from %d on port %d\n", inet_ntoa(cli_addr.sin_addr), htons(cli_addr.sin_port));
		sock_tmp = malloc(1);
		*sock_tmp = sock_aClient;
		printf("Thread count = %d\n", threadCount);
		threadCount--;
		if(pthread_create(&a_thread, NULL, client_handler, sock_tmp) != 0){
			printf("Thread creation failed.\n");
			close(sock_listen);
			close(sock_aClient);
			free(sock_tmp);
			exit(1);
		}
	}//while
	
	n = remove("files.txt");
	if(n != 0){
		printf("Error deleting files.txt....\n");
		exit(1);
	}
	
	return 0;
}

void *client_handler(void *sock_desc){
	int sock = *((int*) sock_desc);
	char buffer[5120000];
	int n, i, j, filefound = 0;
	char file[30], specification[30];
	
	printf("In client handler\n");
	
	//Begin communication
	bzero(buffer, 5120000);
	bzero(file, 30);
	n = read(sock, buffer, 5119999);

		
	if(n<0){
		printf("Error communicating.\n");
		close(sock);
		free(sock_desc);
		exit(1);
	}
		
	i = 9;
	do{
		c = buffer[i];
		file[i - 9] = c;
		i++;
	} while (c != '.');
	
	file[i-10] = '\0';
	strcpy(address, "www.");
	strcat(address, file);
	strcat(address, ".com");
	
	j = 0;
	i += 3;
	do{
		c = buffer[i];
		specification[j] = c;
		i++;
		j++;
	}while(c != ' ');
	
	specification[j] = '\0';
	
	printf("Specification was: %s\n", specification);
	
	for(i = 0; i < 4; i++){
		if(strcmp(blocked[i], file) == 0)
			block = 1;
	}
	strcat(file, ".html");
	
	for(i = 0; i < numfiles; i++){
		if(strcmp(files[i], file) == 0)
			filefound = 1;
	}
	
	
	
	if(block == 1){
		bzero(buffer, 5120000);
		strcpy(buffer, "HTTP/1.1 200 OK\r\n");
		strcat(buffer, "Content-Type: text/html\r\n");
		strcat(buffer, "Content-Language: en\r\n");
		strcat(buffer, "Connection: Keep-Alive\r\n");
		strcat(buffer, "<HTML>\r\n");
		strcat(buffer, "<HEAD>\r\n");
		strcat(buffer, "<TITLE>Page Blocked</TITLE>\r\n");
		strcat(buffer, "</HEAD>\r\n");
		strcat(buffer, "<BODY>\r\n");
		strcat(buffer, "<H1>Page is blocked.</H1>\r\n");
		strcat(buffer, "</BODY>\r\n");
		strcat(buffer, "</HTML>\r\n\r\n\r\n");
		n = write(sock, buffer, 5119999);
		if(n < 0){
			printf("Error writing to socket.\n");
			exit(1);
		}
		printf("Block confirmation sent.\n");
		close(newsockfd);
		close(sockfd);
		exit(1);
	}
	
	bzero(filetoopen, 32);
	strcpy(filetoopen, "./");
	strcat(filetoopen, file);
	
	
	//If the file is in the cache, simply send it to the browser
	if(filefound == 1){
		printf("%s found in cache, displaying...\n", filetoopen);
		fileptr = fopen((const char*)filetoopen, "r");
		if(fileptr == NULL){
			printf("Error opening %s\n", filetoopen);
			exit(1);
		}
		filefd = fileno(fileptr);
		bzero(buffer, 5120000);
		lseek(filefd, 0, SEEK_SET);
		n = read(filefd, buffer, 5119999);
		if(n < 0){
			printf("Error reading from file.\n");
			exit(1);
		}
		n = write(sock, buffer, 5119999);
		if(n < 0){
			printf("Error writing to socket.\n");
			exit(1);
		}
		close(sockfd);
		close(newsockfd);
	//Else, contact the main server, cache the page, and send it to the browser
	}else{
		printf("%s not in cache, contacting main server and caching...\n", filetoopen);
		printf("%s\n", address);
		s = getaddrinfo(address, "80", &hints, &result);
		if( s != 0 ){
			printf("Error getting address info...\n");
			exit(1);
		}
		
		for(rp = result; rp != NULL; rp = rp->ai_next){
			connectfd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
			if(connectfd == -1)
				continue;
			
			if(connect(connectfd, rp->ai_addr, rp->ai_addrlen) != -1)
				break;
		}
		
		bzero(buffer, 5120000);
		
		//Make the HTTP GET request (formatted using the exact GET request I received from my browser)
		if(specification[0] == '\0')
			strcpy(buffer, "GET / HTTP/1.1\r\nHost: ");
		else{
			strcpy(buffer, "GET /");
			strcat(buffer, specification);
			strcat(buffer, " HTTP/1.1\r\nHost: ");
		}
		strcat( buffer, address);
		strcat(buffer, "\r\nConnection: keep-alive\r\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\n");
		strcat(buffer, "User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.116 Safari/537.36\r\n");
		strcat(buffer, "Accept-Language: en-US,en;q=0.8\r\n\r\n");
		
		n = write(connectfd, buffer, 5119999);
		if(n<0){
			printf("Error reading from socket.\n");
			exit(1);
		}
		
		bzero(buffer, 5120000);
		n = read(connectfd, buffer, 5119999);
		if(n<0){
			printf("Error reading from destination url...\n");
			exit(1);
		}
		close(connectfd);
		
		for(i = 0; i < n; i++){
			filter1[0] = buffer[i];
			filter1[1] = buffer[i+1];
			filter1[2] = buffer[i+2];
			filter1[3] = '\0';
			for(j = 0; j < 17; j++){
				if(strcmp(filter1, filter[j]) == 0){
					printf("%s\n", filter1);
					buffer[i] = buffer[i+1] = buffer[i+2] = '*';
					
				}
			}
			
			filter2[0] = buffer[i];
			filter2[1] = buffer[i+1];
			filter2[2] = buffer[i+2];
			filter2[3] = buffer[i+3];
			filter2[4] = '\0';
			for(j=0; j < 17; j++){
				if(strcmp(filter2, filter[j]) == 0){
					printf("%s\n", filter2);
					buffer[i] = buffer[i+1] = buffer[i+2] = buffer[i+3] = '*';
				}
			}
			
			filter3[0] = buffer[i];
			filter3[1] = buffer[i+1];
			filter3[2] = buffer[i+2];
			filter3[3] = buffer[i+3];
			filter3[4] = buffer[i+4];
			filter3[5] = '\0';
			for(j=0; j < 17; j++){
				if(strcmp(filter3, filter[j]) == 0){
					printf("%s\n", filter3);
					buffer[i] = buffer[i+1] = buffer[i+2] = buffer[i+3] = buffer[i+4] = '*';
				}
			}
			
			filter4[0] = buffer[i];
			filter4[1] = buffer[i+1];
			filter4[2] = buffer[i+2];
			filter4[3] = buffer[i+3];
			filter4[4] = buffer[i+4];
			filter4[5] = buffer[i+5];
			filter4[6] = buffer[i+6];
			filter4[7] = '\0';
			for(j=0; j < 17; j++){
				if(strcmp(filter4, filter[j]) == 0){
					printf("%s\n", filter4);
					buffer[i] = buffer[i+1] = buffer[i+2] = buffer[i+3] = buffer[i+4] = buffer[i+5] = buffer[i+6] = '*';
				}
			}
		}
		
		fileptr = fopen((const char*)filetoopen, "w");
		if(fileptr == NULL){
			printf("Error opening %s\n", filetoopen);
			exit(1);
		}

		filefd = fileno(fileptr);
		n = write(filefd, buffer, n);
		if(n<0){
			printf("Error writing to %s...\n", filetoopen);
			exit(1);
		}
		
		n = write(sock, buffer, n);
		if(n<0){
			printf("Error writing to the browser...\n");
			exit(1);
		}
		close(sock);
		free(sock_desc);
		threadCount++;
		
	}
	pthread_exit("Done.\n");
}