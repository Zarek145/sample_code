/***************	
Name: William Brown
Course: CS3110 - Data Structures and Algorithms
Assignment:	Programming Assignment #3
Due	Date: March 26, 2016
****************/
//node.cpp

#include "node.h"

node::node(int v){
	value = v;
	rChild = lChild = parent = NULL;
}

int node::getV(){
	return value;
}

void node::setParent(node* n){
	parent = n;
}

void node::changeV(int v){
	value = v;
}

void node::updateNodeNumber(int n){
	nodeNumber = n;
}