/***************	
Name: William Brown
Course: 3110 Data Structures and Algorithms
Assignment:	Program 3
Due	Date: 4/9/16	
****************/

#include <iostream>
#include <cstdlib>

using namespace std;
double *a;

void Adjust(double *a, int i, int n){
	int child;
	double tmp = a[i];
	
	for( ; i*2 <= n; i = child){
		child = i * 2;
		if(child != n && a[child + 1] < a[child])
			++child;
		if(a[child] < tmp)
			a[i] = a[child];
		else
			break;
	}//for

		a[i] = tmp;
}//Adjust

void Heapify(double *a, int n){
	for(int i = n/2; i >= 1; i--){
		Adjust(a, i, n);
	}//for
}//Heapify

void HeapSort(double *a, int n){
	double t;
	Heapify(a, n);
	for(int i = n; i >=2; i--){
		t=a[i];
		a[i] = a[1];
		a[1] = t;
		Adjust(a, 1, i-1);
	}//for
}//HeapSort

void postorder(int n, int num){
	if(n < num){
		postorder(2*n, num);
		postorder(2*n + 1, num);
		if(n!= 1)
			cout << a[n] << ", ";
		if(n == 1)
			cout << a[n];
	}//if
	else return;
}//postorder

int main(){
	int numEntries = 1, i, numDel;
	char c;
	double find, change;
	a = new double[501];
	for(int i = 0; i < 501; i++)
		a[i] = 10000000.0;
	
	while(1){
		cin >> c;
		if(c == 'I'){
			cin >> a[numEntries];
			Heapify(a, numEntries);
			numEntries++;
		}//if
		else if(c == 'C'){
			cin >> find >> change;
			for(int i = 0; i < numEntries; i++){
				if(a[i] == find)
					a[i] = change;
			}//for
		}//else if
		else if(c == 'P'){
			i = 1;
			postorder(i, numEntries);
			cout << endl;
		}//else if
		else if(c == 'D'){
			cin >> find;
			numDel = 0;
			for(int i = numEntries; i>=1; i--){
				if(a[i] == find){
					for(int j = i; j < numEntries; j++){
						a[j] = a[j+1];
					}
					numDel++;
				}
			}
			numEntries -= numDel;
			Heapify(a, numEntries);
		}
		else if(c == 'Q')
			break;
	}
	
	return 0;
}