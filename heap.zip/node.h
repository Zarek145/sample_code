/***************	
Name: William Brown
Course: CS3110 - Data Structures and Algorithms
Assignment:	Programming Assignment #3
Due	Date: March 26, 2016
****************/
//node.h

#ifndef NODE_H
#define NODE_H

#include <stddef.h>

class node{
	private:
		int value;
		int nodeNumber;
	public:
		node(int v);
		int getV();
		void changeV(int v);
		node* lChild;
		node* rChild;
		node* parent;
		void setParent(node* n);
		void updateNodeNumber(int n);
};

#endif