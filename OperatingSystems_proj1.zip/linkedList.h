/*
Name: William Brown
Class: CS4600 - OS Design
Due Date: Feb. 18, 2016
Assignment: Homework 2
*/
//linkedList.h

#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include "node.h"


class linkedList{
	private:
		node* m_pHead;
		node* m_pTail;
		int m_nSize;
	public:
		linkedList();
		void insert(int pID, double numCyc, double memSize);
		void print();
		void printCycDist();
		void printSizeDist();
};

#endif