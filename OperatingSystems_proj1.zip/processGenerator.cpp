/*
Name: William Brown
Class: CS4600 - OS Design
Due Date: Feb. 18, 2016
Assignment: Homework 2
*/
//processGenerator.cpp

#include "node.h"
#include "linkedList.h"
#include <cstdlib>
#include <cmath>
#include <limits>
#include <iostream>
#include <ctime>

using namespace std;

double* random(int mean, int size, int min, int max){
	int range;
	bool withinRange = false;
	bool* withinRangeArray;
	double average;
	
	withinRangeArray = new bool[size];
	
	if(min == 1){
		range = max;
	}
	else{
		range = max - min;
	}
	time_t timer;
	timer = time(NULL);
	srand(timer);
	double* a = new double[size];
	while(withinRange != true){
		withinRange = true;
		for(int i = 0; i < size; i++){
			a[i] = rand() % range + min;
		}
		
		double sum = 0;
		for(int i = 0; i < size; i++){
				sum += a[i];
		}
		average = sum/size;
		
		
		for(int i = 0; i < size; i++){
			a[i] *= mean/average;
		}
		
		sum = 0;
		for(int i = 0; i < size; i++){
			sum += a[i];
		}
		
		average = sum/size;
		
		for(int i = 0; i < size; i++){
			if(a[i] >= min && a[i] <= max)
				withinRangeArray[i] = true;
			else
				withinRangeArray[i] = false;
			withinRange = withinRange && withinRangeArray[i];
		}
	}
	//cout << average << endl;
	
	return a;
}

int main(){
	int mean1 = 6000, mean2 = 20;
	double*	d_numCycles;
	double* memSize;
	int* n_numCycles;
	double*** processes;
	int l;
	linkedList* ll = new linkedList();
	time_t timer;
	timer = time(NULL);
	
	srand(timer);
	
	int firstPID = rand() % (32768-l) + 1;
	
	l = 50;
	n_numCycles = new int[l];
	
	d_numCycles = random(mean1, l, 1000, 11000);
	for(int i = 0; i < l; i++){
		n_numCycles[i] = (int)d_numCycles[i];
	}
	memSize = random(mean2, l, 1, 100);
	int j = 0;
	for(int i = firstPID; i < firstPID + l; i++){
		ll->insert( i, n_numCycles[j], memSize[j] );
		j++;
	}
	
	ll->print();
	return 0;
}