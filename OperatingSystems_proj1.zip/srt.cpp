/*
Name: William Brown
Due Date: March 23, 2016
Assignment: Project 1
*/

#include <iostream>
#include <string>

using namespace std;

int main(){
	int numPC = 0;//# of Processes Completed
	int numCT = 0;//# of Cycles Total
	int procs[50][7][1];
	int actProc = 1;//# of active processes
	int currentProc = 0, lastProc = 0;//ID of the current process, changes from 0 to N-1
	int wait[50];
	int cyc;
	int totContSwitch = 0;
	
	/*
	procs[x][0][x] is the total cycles
	procs[x][1][x] is the remaining cycles
	procs[x][2][x] is whether or not the process has finished (0 for not finished, 1 for finished)
	procs[x][3][x] is when the process finished
	procs[x][4][x] is no longer used
	procs[x][5][x] is no longer used
	procs[x][6][x] is when the process arrived in the queue
	*/
	for(int i = 0; i < 50; i++){
		cin >> cyc;
		procs[i][0][0] = procs[i][1][0] = cyc;
	}//for
	
	for(int i = 0; i < 50; i++){
		procs[i][2][0] = procs[i][5][0] = procs[i][6][0] = 0;
		procs[i][3][0] = procs[i][4][0] = -1;
	}//for
	
	
	cout << "We assume that the first process was already active on the system, i.e. there is no context switch penalty for the first process, it just starts executing." << endl << endl;
	
	currentProc = 0;
	
	while (numPC < 50){
		
		if(currentProc != lastProc){
			totContSwitch += 10;
			cout << "Process #" << currentProc << " swapped in and Process #" << lastProc << " swapped out at cycle " << numCT << endl;
			numCT += 10;
		}

			
		lastProc = currentProc;
		if(procs[currentProc][1][0] > 0)
			procs[currentProc][1][0]--;
		if(procs[currentProc][2][0] == 0 && procs[currentProc][1][0] == 0 ){
			cout << "Process #" << currentProc << " has finished at " << numCT << ", it arrived at " << procs[currentProc][6][0]  << " and had " << procs[currentProc][0][0] << " total cycles." << endl;
			procs[currentProc][2][0] = 1;
			procs[currentProc][3][0] = numCT + 1;
			numPC++;
		}//else if
		
		numCT++;

		
		if(actProc < 50 && numCT %50 == 0){
			cout << "Process #" << actProc << " arrived at cycle " << numCT << " with total cycles equal to " << procs[actProc][0][0] << endl;
/* 			cout << numCT << endl << endl;
			for(int i = 0; i < 50; i++)
				cout << procs[i][1][0] << endl; */
			procs[actProc][6][0] = numCT;
			actProc++;
			//cout << endl << endl;
		}//if
		
		for(int i = 0; i < actProc; i++){
			if(procs[i][2][0] == 0)
				currentProc = i;
		}//for
		
		
		for(int i = 0; i < actProc; i++){//finds the process with the Shortest Remaining Time(SRT)
			if(procs[i][1][0] < procs[currentProc][1][0] && procs[i][1][0] > 0){
				currentProc = i;
			}
		}//for
		
	}//while

	
	
	for(int i = 0; i < 50; i++){
		wait[i] = procs[i][3][0] - procs[i][6][0] - procs[i][0][0];
	}
	
	

	
	int sum = 0;
	for( int i = 0; i < 50; i++ ){
		cout << "The wait time of Process #" << i << " was " << wait[i] << " cycles." << endl;
		sum += wait[i];
	}
	
	sum /= 50;
	
	cout << endl  << "The total context switch penalty was " << totContSwitch << " cycles." << endl;
	cout << endl << "The average wait time of all 50 processes was " << sum << " cycles." << endl;
	cout << endl;
}