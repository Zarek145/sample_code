/*
Name: William Brown
Due Date: March 23, 2016
Assignment: Project 1
*/

#include <iostream>
#include <string>

using namespace std;

int main(){
	int numPC = 0;//# of Processes Completed
	int numCT = 0, numCT0 = 0, numCT1 = 0, numCT2 = 0, numCT3 = 0;//# of Cycles Total
	int procs[50][8][1];
	int actProc = 4;//# of active processes
	int currentProc0 = 0, lastProc0 = 0, currentProc1 = 0, lastProc1 = 1, currentProc2 = 0, lastProc2 = 2, currentProc3 = 0, lastProc3 = 3;//ID of the current process, changes from 0 to N-1
	int wait[50];
	int cyc;
	int procNum = 0;
	int totContSwitch = 0;
	
	/*
	procs[x][0][x] is the total cycles
	procs[x][1][x] is the remaining cycles
	procs[x][2][x] is whether or not the process has finished (0 for not finished, 1 for finished)
	procs[x][3][x] is when the process finished, -1 by default
	procs[x][4][x] is a way to keep track of context switches, whenever a process swaps in it is 
						set to 10 and decremented instead of the remaining cycles until it reaches 
						zero, at which point the remaining cycles are decremented
	procs[x][5][x] is no longer used
	procs[x][6][x] is when the process arrived in the queue
	procs[x][7][x] is the processor that the process is assigned to
	*/
	for(int i = 0; i < 50; i++){
		cin >> cyc;
		procs[i][0][0] = procs[i][1][0] = cyc;
	}//for
	
	for(int i = 0; i < 50; i++){
		procs[i][2][0] = procs[i][5][0] = procs[i][6][0] = procs[i][4][0] = 0;
		procs[i][7][0] = procs[i][3][0] = -1;
	}//for
	procs[0][7][0] = 0;
	procs[1][7][0] = 1;
	procs[2][7][0] = 2;
	procs[3][7][0] = 3;
	cout << "We assume that the first four processes are already active on the system, \ni.e. there is no context switch penalty for the first four processes, they just starts executing." << endl << endl;
	
	currentProc0 = 0;
	currentProc1 = 1;
	currentProc2 = 2;
	currentProc3 = 3;
	
	while (numPC < 50){
		
		 if(currentProc0 != lastProc0){
			totContSwitch += 10;
			procs[currentProc0][4][0] = 10;
			cout << "Process #" << currentProc0 << " swapped in and Process #" << lastProc0 << " swapped out at cycle " << numCT << " on Processor #" << procs[currentProc0][7][0] << endl;
		}

			
		if(currentProc1 != lastProc1){
			totContSwitch += 10;
			procs[currentProc1][4][0] = 10;
			cout << "Process #" << currentProc1 << " swapped in and Process #" << lastProc1 << " swapped out at cycle " << numCT << " on Processor #" << procs[currentProc1][7][0] << endl;
		}
			
		 if(currentProc2 != lastProc2){
			totContSwitch += 10;
			procs[currentProc2][4][0] = 10;
			cout << "Process #" << currentProc2 << " swapped in and Process #" << lastProc2 << " swapped out at cycle " << numCT << " on Processor #" << procs[currentProc2][7][0] << endl;
		}
			
		
		if(currentProc3 != lastProc3){
			totContSwitch += 10;
			procs[currentProc3][4][0] = 10;
			cout << "Process #" << currentProc3 << " swapped in and Process #" << lastProc3 << " swapped out at cycle " << numCT << " on Processor #" << procs[currentProc3][7][0] << endl;
		}
			
		lastProc0 = currentProc0;
		if(procs[currentProc0][1][0] > 0 && procs[currentProc0][7][0] == 0 && procs[currentProc0][4][0] == 0)
			procs[currentProc0][1][0]--;
		else
			procs[currentProc0][4][0]--;
		if(procs[currentProc0][2][0] == 0 && procs[currentProc0][1][0] == 0 && procs[currentProc0][7][0] == 0 ){
			procs[currentProc0][2][0] = 1;
			procs[currentProc0][3][0] = numCT + 1;
			cout << "Process #" << currentProc0 << " finished on Processor #0 at cycle " << numCT << endl;
			numPC++;
		}//if	
		
		lastProc1 = currentProc1;
		if(procs[currentProc1][1][0] > 0 && procs[currentProc1][7][0] == 1 && procs[currentProc1][4][0] == 0)
			procs[currentProc1][1][0]--;
		else
			procs[currentProc1][4][0]--;
		if(procs[currentProc1][2][0] == 0 && procs[currentProc1][1][0] == 0 && procs[currentProc1][7][0] == 1 ){
			procs[currentProc1][2][0] = 1;
			procs[currentProc1][3][0] = numCT + 1;
			cout << "Process #" << currentProc1 << " finished on Processor #1 at cycle " << numCT << endl;
			numPC++;
		}//if	
		
		lastProc2 = currentProc2;
		if(procs[currentProc2][1][0] > 0 && procs[currentProc2][7][0] == 2 && procs[currentProc2][4][0] == 0)
			procs[currentProc2][1][0]--;
		else
			procs[currentProc2][4][0]--;
		if(procs[currentProc2][2][0] == 0 && procs[currentProc2][1][0] == 0 && procs[currentProc2][7][0] == 2 ){
			procs[currentProc2][2][0] = 1;
			procs[currentProc2][3][0] = numCT + 1;
			cout << "Process #" << currentProc2 << " finished on Processor #2 at cycle " << numCT << endl;
			numPC++;
		}//if
		
		lastProc3 = currentProc3;
		if(procs[currentProc3][1][0] > 0 && procs[currentProc3][7][0] == 3 && procs[currentProc3][4][0] == 0)
			procs[currentProc3][1][0]--;
		else
			procs[currentProc3][4][0]--;
		if(procs[currentProc3][2][0] == 0 && procs[currentProc3][1][0] == 0 && procs[currentProc3][7][0] == 3){
			procs[currentProc3][2][0] = 1;
			procs[currentProc3][3][0] = numCT + 1;
			cout << "Process #" << currentProc3 << " finished on Processor #3 at cycle " << numCT << endl;
			numPC++;
		}//if
		numCT++;

		
		if(actProc < 50 && numCT %50 == 0){
			cout << "Process #" << actProc << " arrived at cycle " << numCT << ", it went to Processor #" << procNum << endl;
/* 			cout << numCT << endl << endl;
			for(int i = 0; i < 50; i++)
				cout << procs[i][1][0] << endl; */
			procs[actProc][6][0] = numCT;
			procs[actProc][7][0] = procNum;
			procNum++;
			if(procNum > 3)
				procNum = 0;
			actProc++;
		}//if
/* 		if(actProc == 50 && numCT%50 == 0){
			for(int i = 0; i < 50; i++)
				cout << procs[i][1][0] << endl;
				
			cout << endl << endl;
		} */
		
		for(int i = 0; i < actProc; i++){
			if(procs[i][2][0] == 0 && procs[i][7][0] == 0)
				currentProc0 = i;
			if(procs[i][2][0] == 0 && procs[i][7][0] == 1)
				currentProc1 = i;
			if(procs[i][2][0] == 0 && procs[i][7][0] == 2)
				currentProc2 = i;
			if(procs[i][2][0] == 0 && procs[i][7][0] == 3)
				currentProc3 = i;
		}//for
		
		
		for(int i = 0; i < actProc; i++){//finds the process with the Shortest Remaining Time(SRT)
			if(procs[i][1][0] < procs[currentProc0][1][0] && procs[i][1][0] > 0 && procs[i][7][0] == 0){
				currentProc0 = i;
			}
			if(procs[i][1][0] < procs[currentProc1][1][0] && procs[i][1][0] > 0 && procs[i][7][0] == 1){
				currentProc1 = i;
			}
			if(procs[i][1][0] < procs[currentProc2][1][0] && procs[i][1][0] > 0 && procs[i][7][0] == 2){
				currentProc2 = i;
			}
			if(procs[i][1][0] < procs[currentProc3][1][0] && procs[i][1][0] > 0 && procs[i][7][0] == 3){
				currentProc3 = i;
			}
		}//for
		
/* 		cout << currentProc << "..." << lastProc << endl << endl;
		cout << endl << endl; */
	}//while
	/* for(int i = 0; i < 50; i++){
		cout << "Total cycles: " << procs[i][0][0] <<  ", ";
		cout << "Remaining cycles: " << procs[i][1][0] << endl;
		cout << "Processor number: " << procs[i][7][0] << endl;
	} */
	
	cout << endl;
	
	for(int i = 0; i < 50; i++){
		wait[i] = procs[i][3][0] - procs[i][6][0] - procs[i][0][0];
		
	}

	
	/* for(int i = 0; i < 50; i++){
		cout << i << ":" << procs[i][3][0] << "...." << procs[i][4][0] << endl;
		cout << "arrived: " << procs[i][6][0] << endl;
	}	 */
	
	int sum = 0;
	for( int i = 0; i < 50; i++ ){
		cout << "Process #" << i << " waited " << wait[i] << " cycles." << endl;
		sum += wait[i];
	}
	
	sum /= 50;
	
	cout << endl << "The total context switch penalty was " << totContSwitch  << " cycles." << endl;
	cout << endl << "The average wait time for this trial was " << sum << " cycles." << endl;
	cout << endl;
}