/*
Name: William Brown
Class: CS4600 - OS Design
Due Date: Feb. 18, 2016
Assignment: Homework 2
*/
//node.cpp

#include "node.h"

node::node( int pID, double numCyc, double memSize ){
	prv_ProcessId = pID;
	prv_NumCycles = numCyc;
	prv_MemSize = memSize;
}