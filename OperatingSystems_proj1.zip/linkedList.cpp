/*
Name: William Brown
Class: CS4600 - OS Design
Due Date: Feb. 18, 2016
Assignment: Homework 2
*/
//linkedList.cpp

#include <iostream>
#include "node.h"
#include "linkedList.h"

using namespace std;

node* n;
node* curr;

linkedList::linkedList(){
	m_pHead = m_pTail = NULL;
	m_nSize = 0;
}

void linkedList::insert( int pID, double numCyc, double memSize ){
	if(m_nSize == 0){
		n = new node( pID, numCyc, memSize );
		m_pHead = m_pTail = curr = n;
		curr->m_pNext = NULL;
		m_nSize++;
	}
	else{
		n = new node( pID, numCyc, memSize );
		m_pTail = n;
		curr->m_pNext = n;
		curr = n;
		curr->m_pNext = NULL;
		m_nSize++;
	}
	return;
}

void linkedList::print(){
	curr = m_pHead;
	for(int i = 0; i < m_nSize; i++){
		cout << curr->prv_NumCycles << " ";
		curr = curr->m_pNext;
	}
	return;
}

void linkedList::printCycDist(){
	int a[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	curr = m_pHead;
	for( int i = 0; i < m_nSize; i++ ){
		if( curr->prv_NumCycles >= 1000 && curr->prv_NumCycles <= 2000)
			a[0]++;
		else if( curr->prv_NumCycles > 2000 && curr->prv_NumCycles <= 3000)
			a[1]++;
		else if( curr->prv_NumCycles > 3000 && curr->prv_NumCycles <= 4000)
			a[2]++;
		else if( curr->prv_NumCycles > 4000 && curr->prv_NumCycles <= 5000)
			a[3]++;
		else if( curr->prv_NumCycles > 5000 && curr->prv_NumCycles <= 6000)
			a[4]++;
		else if( curr->prv_NumCycles > 6000 && curr->prv_NumCycles <= 7000)
			a[5]++;
		else if( curr->prv_NumCycles > 7000 && curr->prv_NumCycles <= 8000)
			a[6]++;
		else if( curr->prv_NumCycles > 8000 && curr->prv_NumCycles <= 9000)
			a[7]++;
		else if( curr->prv_NumCycles > 9000 && curr->prv_NumCycles <= 10000)
			a[8]++;
		else if( curr->prv_NumCycles > 10000 && curr->prv_NumCycles <= 11000)
			a[9]++;
		
		curr = curr->m_pNext;
	}
	
	cout << "The number of cycles distribution appears as follows:" << endl << endl;
	
	for(int i = 0; i < 10; i++){
		cout << i << ":";
		for(int j = 0; j < a[i]; j++){
			cout << "*";
		}//j
		cout << endl;
	}//j
}

void linkedList::printSizeDist(){
	int a[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	curr = m_pHead;
	for( int i = 0; i < m_nSize; i++ ){
		if( curr->prv_MemSize >= 1 && curr->prv_MemSize <= 10)
			a[0]++;
		else if( curr->prv_MemSize > 10 && curr->prv_MemSize <= 20)
			a[1]++;
		else if( curr->prv_MemSize > 20 && curr->prv_MemSize <= 30)
			a[2]++;
		else if( curr->prv_MemSize > 30 && curr->prv_MemSize <= 40)
			a[3]++;
		else if( curr->prv_MemSize > 40 && curr->prv_MemSize <= 50)
			a[4]++;
		else if( curr->prv_MemSize > 50 && curr->prv_MemSize <= 60)
			a[5]++;
		else if( curr->prv_MemSize > 60 && curr->prv_MemSize <= 70)
			a[6]++;
		else if( curr->prv_MemSize > 70 && curr->prv_MemSize <= 80)
			a[7]++;
		else if( curr->prv_MemSize > 80 && curr->prv_MemSize <= 90)
			a[8]++;
		else if( curr->prv_MemSize > 90 && curr->prv_MemSize <= 100)
			a[9]++;
		
		curr = curr->m_pNext;
	}
	
	cout << "The memory size distribution appears as follows:" << endl << endl;
	
	for(int i = 0; i < 10; i++){
		cout << (i+1) << ":";
		for(int j = 0; j < a[i]; j++){
			cout << "*";
		}//j
		cout << endl;
	}//i
}