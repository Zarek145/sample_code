/*
Name: William Brown
Class: CS4600 - OS Design
Due Date: Feb. 18, 2016
Assignment: Homework 2
*/
//node.h

#ifndef NODE_H
#define NODE_H

class node{
	friend class linkedList;
	private:
		int prv_ProcessId;
		double prv_NumCycles;
		double prv_MemSize;
		node* m_pNext;
	public:
		node( int pID, double numCyc, double memSize );
};

#endif