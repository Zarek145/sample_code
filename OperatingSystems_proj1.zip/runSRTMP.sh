#! /bin/bash

./pg | ./srtMP > outputMP.txt
