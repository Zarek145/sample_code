#! /bin/bash

./pg | ./srt > output.txt

