I've included 3 makefiles: one for srt, one for srtMP, and one for the processGenerator.
To compile SRT with a single processor, use the command make -f srt_makefile
To compile SRT with multiple processors, use the command make -f srtMP_makefile
To compile the processGenerator, use the command make -f pg_makefile

I've included 2 bash scripts as well. In order to run them you must type chmod u+x runSRT.sh or chmod u+x runSRTMP.sh.
To run either, simply type ./runSRT.sh or ./runSRTMP.sh, they will run the process generator, pipe the output into the desired srt,
	and finally print all of the output to a file called output.txt or outputMP.txt respectively.

Edit: This was a group project, where my groupmate Dalton Barret and I were tasked with simulating: 1.) A process scheduling method
with a single processor (we chose SRT), 2.) A process scheduling method with multiple processors (again we chose SRT), and finally
we had to run a set of processes that were generated according to restraints the average of the set of processes was 6000 cycles and
the range was between 1000 cycles and 11000 cycles.