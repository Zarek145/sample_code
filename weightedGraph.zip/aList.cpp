//aList.cpp

#include "node.h"
#include "aList.h"

node* n;
node* curr;
node* temp1;
node* temp2;

using namespace std;

aList::aList(){
	head = NULL;
	count = 0;
}

void aList::insert(int d, int w){
	if(count == 0){//this segment of code creates a head node if there isn't one yet
		n = new node(d, w);
		n->next = NULL;
		head = n;
		curr = n;
		count++;
	}
	else if(count > 0){//this segment of code first checks to see if the edge is already created,
		temp1 = head;//if it is then it simply replaces the weight, if not it creates the edge.
		for(int i = 0; i < count; i++){
			if(temp1->edge == d){
				temp1->weight = w;
				return;
			}
			temp1 = temp1->next;
		}
		n = new node(d, w);
		n->next = NULL;
		curr->next = n;
		curr = n;
		count++;
	}
}

void aList::remove(int d){
	temp1 = head;
	temp2 = head;
	int i = 0;
	while(i < count){
		if(temp1->edge == d && i == 0 && count == 1){//if the edge is the only node, simply set the head to null
			head = NULL;
			count--;
		}
		else if(temp1->edge == d && i == 0){//if the edge is the head and there is something after it,
			temp1 = temp1->next;//remove the head and create a new head.
			temp2 = temp1;
			head = temp2;
			i++;
			count--;
			temp2 = temp2->next;
			temp1 = temp1->next;
		}
		else if(temp1->edge == d){//looks for the edge through the rest of the list if its not the head
			temp1 = temp1->next;
			temp2 = temp1;
			temp1 = temp1->next;
			temp2 = temp2->next;
			i++;
			count--;
		}
		
		
	}
}

void aList::print(int b){//prints the list of each bucket
	temp1 = head;
	for(int i = 0; i < count; i++){
		cout << "(" << b << "," << temp1->edge << "," << temp1->weight << ")";
		temp1 = temp1->next;
	}
}