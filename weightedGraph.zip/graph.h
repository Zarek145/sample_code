//graph.h

#ifndef GRAPH_H
#define GRAPH_H

#include "node.h"
#include "aList.h"
#include <iostream>

class graph{
	private:
		aList** gr;
	public:
		int c;
		graph();
		void create(int x);
		void print();
		void remove(int s, int d);
		void insert(int s, int d, int w);
};

#endif