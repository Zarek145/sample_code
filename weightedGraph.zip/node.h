//node.h

#ifndef NODE_H
#define NODE_H

#include <iostream>

class node{
	friend class aList;
	friend class graph;
	private:
		int edge, weight;
		node* next;
	public:
		node(int eg, int wt);
};

#endif