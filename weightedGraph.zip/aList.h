//aList.h

#ifndef ALIST_H
#define ALIST_H

#include "node.h"

class aList{
	friend class graph;
	private:
		node* head;
		int count;
	public:
		aList();
		void insert(int d, int w);
		void remove(int d);
		void print(int b);
};

#endif

