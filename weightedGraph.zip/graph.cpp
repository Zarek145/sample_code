//graph.cpp

#include "graph.h"
#include "node.h"
#include "aList.h"
#include <iostream>

using namespace std;

graph::graph(){
	gr = NULL;
}

void graph::create(int x){//creates a list of specified size and sets creates lists for all buckets
	gr = new aList*[x];
	c = x;
	for(int i = 0; i < x; i++)
		gr[i] = new aList();
}

void graph::insert(int s, int d, int w){//inserts the destination and weight into the specified bucket
	gr[s]->insert(d, w);
}

void graph::remove(int s, int d){
	node* temp;
	int count;
	int i = 0;
	if(gr[s]->head == NULL){//checks to see if the edge doesn't exist
		cout << "Error! Edge does not exist." << endl;
		return;
	}
	else if(gr[s]->head != NULL){
		temp = gr[s]->head;
		count = gr[s]->count;
		while(i < count){//checks to see if the edge exists, if it does remove it from the array
			if(temp->edge == d){
				gr[s]->remove(d);
				return;
			}
			else{
				i++;
				temp = temp->next;
			}
		}
		if(i == count){//if the edge doesn't exist, prints the appropriate message
			cout << "Error! Edge does not exist." << endl;
		}	
	}
	
	
	
}

void graph::print(){
	for(int i = 0; i < c; i++){//prints all linked lists from all buckets
		gr[i]->print(i);
	}
	cout << endl;
}