//main.cpp

#include "node.h"
#include "aList.h"
#include "graph.h"
#include <iostream>
#include <string>

using namespace std;

int main(){
	int x, s, d, w;
	graph* g = new graph();
	string cmd;
	
	while(true){//this takes commands and all necessary parameters and feeds them into the graph
		cout << "graph> ";
		cin >> cmd;
		
		if (cmd == "create"){//if the cmd is create, take # of buckets and create array list of that size
			cin >> x;
			g->create(x);
		}
		else if(cmd == "insert"){//if cmd is insert, take source, destination and weight and insert
			cin >> s >> d >> w;
			if(s >= g->c || d >= g->c){//if either node is greater than the bucket amount,
				cout << "Error! Node does not exist." << endl;//print the appropriate error message
			}
			else{
			g->insert(s, d, w);
			}
		}
		else if(cmd == "remove"){//if cmd is remove, take source and destination and remove
			cin >> s >> d;
			if(s >= g->c || d >= g->c)//if either edge is greater than the bucket, print appropriate error message
				cout << "Error! Edge does not exist." << endl;
			else
				g->remove(s, d);
		}
		else if(cmd == "print"){
			g->print();
		}
		else if(cmd == "quit"){
			break;
		}
		else{//if none of the commands received are valid commands, print appropriate message
			cout << "Error! Unsupported command." << endl;
		}
	}
}