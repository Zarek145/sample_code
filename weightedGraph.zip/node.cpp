//node.cpp

#include "node.h"

node::node(int eg, int wt){
	weight = wt;
	edge = eg;
}