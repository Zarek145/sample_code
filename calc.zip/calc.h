//calc.h
#ifndef CALC_H
#define CALC_H

#include <string>
#include <iostream>
#include <sstream>
#include <stdlib.h>

using namespace std;

class calc {
	private:
		friend class results;
	public:
		calc( );//Constructor
		void multiply( int, int, int );
		void divide( int, int, int );
		void add( int, int, int );
		void subtract( int, int, int );
		int binary( int, int, int );
		void print( int m );
		
};

#endif