//results.h

#ifndef RESULTS_H
#define RESULTS_H

#include <string>
#include <iostream>
#include <sstream>
#include <stdlib.h>

using namespace std;

class results {
	protected:
		friend class calc;
		int m_pData;
	public:
		results( int );
};

#endif