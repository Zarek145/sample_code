#include "calc.h"
#include "results.h"
#include <string>
#include <iostream>
#include <sstream>
#include <stdlib.h>

using namespace std;
int result;
int A[10];
results** R = new results*[20];




void calc::multiply( int first, int second, int m ){//reads in numbers from the main and outputs them
	result = first * second;
	R[m] = new results(result);
	cout << result << endl;
}

void calc::divide( int first, int second, int m ){//reads in numbers from the main and outputs them
	result = first / second;
	R[m] = new results(result);
	cout << result << endl;
}

void calc::add( int first, int second, int m ) {//reads in numbers from the main and outputs them
	result = first + second;
	R[m] = new results(result);
	cout << result << endl;
}

void calc::subtract( int first, int second, int m  ) {//reads in numbers from the main and outputs them
	result = first - second;
	R[m] = new results(result);
	cout << result << endl;
}

int calc::binary( int first, int second, int m  ) {//reads in a number and the variable that controls where the result of first % 2 is stored.
	stringstream temp;

	
	
	if (first > 0) {
		A[second] = first % 2;
		return binary( first / 2, second + 1, m );
	}
	else if ( first == 0 ) {
		while ( second > 0 ){
			temp << A[second - 1];
			second--;
		}
		result = atoi(temp.str().c_str());
		R[m] = new results(result);
		cout << result << endl; 
		return 0;
	}
}

void calc::print( int m ) {
	cout << R[0]->m_pData;
	if (  m != 1 ){
		for ( int i = 1; i < m - 1; i++){
			cout << "-" << R[i]->m_pData;
		}
	
		cout << "-" << R[m-1]->m_pData << endl;
	}
	else
		cout << endl;
}

calc::calc(  ) {//constructs a calc class that carries out any of the functions
	for( int i = 0; i < 20; i++)
		R[i] = NULL;

}