//results.cpp

#include "calc.h"
#include "results.h"
#include <string>
#include <iostream>
#include <sstream>
#include <stdlib.h>

using namespace std;
	

results::results(int result) {
	m_pData = result;
}

