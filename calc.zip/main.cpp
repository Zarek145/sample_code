#include "calc.h"
#include "results.h"
#include <string> 
#include <iostream>
#include <sstream>
#include <stdlib.h>

using namespace std;

int main() {
	string math = "";
	string s = "calc> ";
	int x=0, y=0, m = 0;
	calc* c = new calc;
	
	while ( true ){
		cout << s;//Prompt for calculations and variables
		cin >> math;
		if ( math == "add" ){
			cin >> x >> y;
			c->add( x, y, m);
			m++;
		}
		else if ( math == "subtract" ) {
			cin >> x >> y;
			c->subtract( x, y, m);
			m++;			
		}
		else if ( math == "multiply" ) {
			cin >> x >> y;
			c->multiply( x, y, m);
			m++;
		}
		else if ( math == "divide" ) {
			cin >> x >> y;
			c->divide( x, y, m);
			m++;
		}
		else if ( math == "binary" ) {
			cin >> x;
			c->binary( x, 0, m);
			m++;
		
		}
		else if ( math == "quit" )
			break;
		else if (math == "results") 
			c->print(m);
		else{
			cout << "Error! " << endl;
		}
		
	}
	
	return 0;
}